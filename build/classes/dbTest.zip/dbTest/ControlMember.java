/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 *  Memberテーブル問い合わせ処理　コントロール
 * @author 17jz0101 Lee Ho Jae
 */
public class ControlMember {
    private BoundaryMember  boundary;
    private List<Member>    memberList;
    private MemberDAO       memberDAO;
    
    public ControlMember() {
        boundary = new BoundaryMember();
        memberList = new ArrayList<>();
        memberDAO = new MemberDAO();
    }
    
    public void start() {
        boundary.setControl(this);
        boundary.setVisible(true);
    }
    
    /**
     * テーブルの内容全件表示
     */
    public void showMemberAll() {
        memberList = memberDAO.dbSearchMemberAll();
        boundary.showMemberTextArea(memberList);
    }
    
    public static void main(String[] args) {
        new ControlMember().start();
    }
    
    /**
     * NAME = "鈴木" のデータを表示
     */
    public void showMemberNameSuzuki() {
        memberList = memberDAO.dbSearchMemberSuzuki();
        boundary.showMemberTextArea(memberList);
    }

    /**
     * IDを検索して該当するデータを表示
     * @param id 
     */
    void showMemberSearchId(String id) {
        try {
            if(!id.isEmpty()) {
                memberList = memberDAO.dbSearchMemberId(Integer.parseInt(id));
                if(memberList.size() > 0) {
                    boundary.showMemberTextArea(memberList);
                } else {
                    boundary.showNotFoundErrorMessage(id);
                }
            } else {
                boundary.showParmNothingErrorMessage();
            }
        } catch(NumberFormatException e) {
            boundary.showFormatErrorMessage();
        }
    }
    
    /**
     * NAMEを検索して該当するデータを表示
     * @param name 
     */
    void showMemberSearchName(String name) {
        memberList = memberDAO.dbSearchMemberName(name);
        if(memberList.size() > 0) {
            boundary.showMemberTextArea(memberList);
        } else {
            boundary.showNotFoundErrorMessage(name);
        }
    }
    
    /**
     * 名前のLIKE検索を行い結果を表示する
     * @param name 
     */
    void showMemberSearchNameLike(String name) {
        memberList = memberDAO.dbSearchNameLike(name);
        if(memberList.size() > 0) {
            boundary.showMemberTextArea(memberList);
        } else {
            boundary.showNotFoundErrorMessage(name);
        }
    }
    
    /**
     * 登録日検索を行い結果を表示する
     * @param entryDate 
     */
    void showMemberEntryDate(String entryDate) {
        try {
            memberList = memberDAO.dbSearchMemberEntryDate(Date.valueOf(entryDate));
            if(memberList.size() > 0) {
                boundary.showMemberTextArea(memberList);
            } else {
                boundary.showNotFoundErrorMessage(entryDate);
            }
        } catch(IllegalArgumentException e) {
            boundary.showFormatErrorMessage();
        }
    }
}
