/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * 会員データベース（Member）アクセスチェック 
 * @author 17jz0101 Lee Ho Jae
 */
public class QueryMember {
    public static void main(String[] args) {
        List<Member> members;
        MemberDAO memberDAO = new MemberDAO();
        // ----- Step1
        members = memberDAO.dbSearchMemberAll();
        for(Member member : members) {
            member.println();
        }
        // ----- Step2
        System.out.println("------------------------------");
        members = memberDAO.dbSearchMemberSuzuki();
        for(Member member : members) {
            member.println();
        }
        // ----- Step3
        System.out.println("------------------------------");
        for(int i = 0; i < 10; i++) {
            System.out.print("id = " + i + " ");
            members = memberDAO.dbSearchMemberId(i);
            for(Member member : members) {
                member.print();
            }
            System.out.println("");
        }
        // ----- Step4
        System.out.println("-------------------------------");
        members = memberDAO.dbSearchMemberName("青木");
        for(Member member : members) {
            member.println();
        }
        
        // ----- Step5
        System.out.println("-------------------------------");
        members = memberDAO.dbSearchMemberEntryDate(Date.valueOf("2018-10-05"));
        for(Member member : members) {
            member.println();
        }
    }
}

/*
run:
1, 鈴木, 2018-10-01
2, 田中, 2018-10-02
3, 青木, 2018-10-03
4, 佐藤, 2018-10-04
5, 渡辺, 2018-10-05
6, 阿部, 2018-10-06
ビルド成功(合計時間: 0秒)
*/

/*
run:
1, 鈴木, 2018-10-01
2, 田中, 2018-10-02
3, 青木, 2018-10-03
4, 佐藤, 2018-10-04
5, 渡辺, 2018-10-05
6, 阿部, 2018-10-06
------------------------------
1, 鈴木, 2018-10-01
ビルド成功(合計時間: 0秒)
*/

/*
run:
1, 鈴木, 2018-10-01
2, 田中, 2018-10-02
3, 青木, 2018-10-03
4, 佐藤, 2018-10-04
5, 渡辺, 2018-10-05
6, 阿部, 2018-10-06
------------------------------
1, 鈴木, 2018-10-01
------------------------------
id = 0 
id = 1 1, 鈴木, 2018-10-01
id = 2 2, 田中, 2018-10-02
id = 3 3, 青木, 2018-10-03
id = 4 4, 佐藤, 2018-10-04
id = 5 5, 渡辺, 2018-10-05
id = 6 6, 阿部, 2018-10-06
id = 7 
id = 8 
id = 9 
ビルド成功(合計時間: 0秒)
*/