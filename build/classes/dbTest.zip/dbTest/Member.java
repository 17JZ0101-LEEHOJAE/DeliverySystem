/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * 会員エンティティクラス
 * @author 17jz0101 Lee Ho Jae
 */
public class Member {
    private Integer id;         //番号
    private String  name;       //名前
    private Date    entryDate;  // 登録日
    
    /**
     * コンストラクタ
     * @param id            番号
     * @param name          名前
     * @param entryDate     登録日
     */
    public Member(Integer id, String name, Date entryDate) {
        setId(id);
        setName(name);
        setEntryDate(entryDate);
    }
    
    /**
     * コンストラクタ
     */
    public Member() {
        this(0, "", Date.valueOf("2018-01-01"));
    }
    
    /**
     * toStringメソッド
     * @return 一覧文字列
     */
    @Override
    public String toString() {
        return getId() + ", " + getName() + ", " + getEntryDate();
    }
    
    /**
     * メンバーの一覧表示（改行なし）
     */
    public void print() {
        System.out.print(this);
    }
    
    /**
     * メンバーの一覧表示（改行あり）
     */
    public void println() {
        print();
        System.out.println("");
    }
    
    public Integer getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public Date getEntryDate() {
        return entryDate;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }
    
    /**
     * Member クラステスト用メイン
     * @param args
     */
    public static void main(String[] args) {
        List<Member> members = new ArrayList<>();
        
        members.add(new Member(101, "すずき", Date.valueOf("2018-09-01")));
        members.add(new Member(102, "たなか", Date.valueOf("2018-09-02")));
        members.add(new Member(103, "あおき", Date.valueOf("2018-09-03")));
        members.add(new Member(104, "わたなべ", Date.valueOf("2018-09-04")));
        
        for(Member member : members) {
            System.out.println(member);
        }
    }
}
