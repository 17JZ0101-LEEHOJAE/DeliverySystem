/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  17jz0101
 * Created: 2018/10/31
 */
DELETE FROM MEMBER;
INSERT INTO MEMBER(ID, "NAME", ENTRY_DATE) VALUES (1, '鈴木', '2018-10-01');
INSERT INTO MEMBER(ID, "NAME", ENTRY_DATE) VALUES (2, '田中', '2018-10-02');
INSERT INTO MEMBER(ID, "NAME", ENTRY_DATE) VALUES (3, '青木', '2018-10-03');
INSERT INTO MEMBER(ID, "NAME", ENTRY_DATE) VALUES (4, '佐藤', '2018-10-04');
INSERT INTO MEMBER(ID, "NAME", ENTRY_DATE) VALUES (5, '渡辺', '2018-10-05');
INSERT INTO MEMBER(ID, "NAME", ENTRY_DATE) VALUES (6, '阿部', '2018-10-06');
