/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 会員DAO (データベースアクセスオブジェクト)
 * @author 17jz0101 Lee Ho Jae
 */
public class MemberDAO {
    private static Connection           con;
    private static PreparedStatement    ps;
    
    /**
     * コンストラクタ
     * データベース接続情報設定
     */
    public MemberDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con                 = dbManager.getConnection();
    }
    
    /**
     * Memberテーブル検索処理実行
     * @return 検索結果のリスト
     */
    public List<Member> selectMemberExecute() {
        List<Member> memberList = new ArrayList<>();
        
        try {
            memberList.clear();
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) {
                Member member = new Member();
                setMember(member, rs);
                memberList.add(member);
            }
            rs.close();
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return memberList;
    }
    
    /**
     * 問い合わせ結果を Memberに設定
     * @param member    問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setMember(Member member, ResultSet rs) {
        try {
            Integer id      = rs.getInt("ID");
            String  name    = rs.getString("NAME");
            Date    entryDate = rs.getDate("ENTRY_DATE");
            member.setId(id);
            member.setName(name);
            member.setEntryDate(entryDate);
        } catch(SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 全件検索
     * @return 検索結果リスト 
     */
    public List<Member> dbSearchMemberAll() {
        List<Member> memberList = new ArrayList<>();
        String sql = "SELECT * " + " FROM MEMBER ";
        
        try {
            ps = con.prepareStatement(sql);
            memberList = selectMemberExecute();
        } catch(SQLException e) {
            e.printStackTrace();
        }
        return memberList;
    }
    
    /**
     * 名前検索"鈴木"を検索
     * @return 検索結果リスト
     */
    public List<Member> dbSearchMemberSuzuki() {
        List<Member> memberList = new ArrayList<>();
        String sql = "SELECT * " + " FROM MEMBER " +
                     " WHERE name = \'鈴木\' ";
        try {
            ps = con.prepareStatement(sql);
            memberList = selectMemberExecute();
        } catch(SQLException e) {
            e.printStackTrace();
        }
        
        return memberList;
    }
    
    /**
     * ID指定による検索
     * @param id    検索キーID
     * @return      検索結果リスト
     */
    public List<Member> dbSearchMemberID(int id) {
        List<Member> memberList = new ArrayList<>();
        String sql = "SELECT * " + " FROM MEMBER " +
                     "WHERE ID = ? ";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            
            memberList = selectMemberExecute();
        } catch(SQLException e) {
            e.printStackTrace();
        }
        
        return memberList;
    }
}
