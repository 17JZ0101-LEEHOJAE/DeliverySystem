/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbTest;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * シングルトンパターンを適用した
 * データベース接続管理クラス
 * @author 17jz0101 Lee Ho Jae
 */
public class DBManager {
    private static DBManager    dbManager = null;
    private static Connection   con = null;
    private static final String driverUrl = "jdbc:derby://localhost:1527/MyDB01";
    private static final String dbUserName = "user01";
    private static final String dbUserPassword = "user01";
    
    /**
     * コンストラクタ
     * ドライバマネージャにJDBCドライバを登録し、URLで指定された場所に存在するデータベースに接続する
     * アクセス修飾子がprivateなので、内部メソッドからしか生成することができない
     */
    private DBManager() {
        try {
            // JavaDB接続用設定
            con = DriverManager.getConnection(driverUrl, dbUserName, dbUserPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * DB接続管理インスタンスの生成を兼ねたゲッター
     * @return DB接続管理インスタンス
     */
    public static DBManager getDBManager() {
        if(DBManager.dbManager == null) {
            DBManager.dbManager = new DBManager();
        }
        
        return DBManager.dbManager;
    }
    
    /**
     * コネクションのゲッター
     * @return コネクション
     */
    public Connection getConnection() {
        return con;
    }
}
