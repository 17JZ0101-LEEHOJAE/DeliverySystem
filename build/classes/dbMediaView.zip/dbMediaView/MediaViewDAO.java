package dbMediaView;

import dbTest.DBManager;
import java.sql.*;
import java.util.*;
/**
 * MediaViewDAO
 * @author 17jz0101 Lee Ho Jae
 */
public class MediaViewDAO {
    private static Connection           con;        // データベースコネクション
    private static PreparedStatement    ps;             // バインド変数を用いたSQL文用
    
    /**
     * コンストラクタ
     *  データベース接続情報設定
     */
    public MediaViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con                 = dbManager.getConnection();
    }
    /**
     * Memberテーブル検索処理実行
     * @return 検索結果のリスト
     */
    public List<MediaView> selectMediaViewExecute() {
        List<MediaView> mediaViewList = new ArrayList<>();        // 問い合わせ結果 Person
        try {            
            // 完成したSQLの実行
            ResultSet rs = ps.executeQuery();
            //　結果の表示            
            while (rs.next()) {     // 検索結果のある間繰り返す
                MediaView mediaView = new MediaView();
                setMediaView(mediaView, rs);          // 検索結果を1件取り出し                
                mediaViewList.add(mediaView);         // 検索結果をリストに登録
            }
            // 後片付け
            rs.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }     
        return mediaViewList;
    }
    /**
     * 問い合せ結果を mediaViewに設定
     * @param mediaView  問い合せ結果を格納
     * @param rs         問い合せ結果
     */
    public void setMediaView(MediaView mediaView, ResultSet rs) {
        try {
            //問い合わせ結果の列情報をJavaのデータ型に受け取る
            String id       = rs.getString("ID");
            String kind     = rs.getString("KIND");
            String category = rs.getString("CATEGORY");
            String title    = rs.getString("TITLE");
            
            mediaView.setId(id);
            mediaView.setKind(kind);
            mediaView.setCategory(category);
            mediaView.setTitle(title);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }  
    /**
     * 全件検索
     * @return 検索結果リスト
     */
    public  List<MediaView> dbSearchMediaViewAll() {
        List<MediaView> mediaViewList = new ArrayList<>();
        String sql = "SELECT * " +              // 全件検索用SQL
                     " FROM MEDIA_VIEW " +
                     " ORDER BY ID ";
       try {
            ps = con.prepareStatement(sql);     // SQLを実行するためのステートメント作成
            mediaViewList = selectMediaViewExecute(); // SQLの実行
       }
       catch (SQLException e) {    
           e.printStackTrace();    
       }        
       return mediaViewList;
    }
    /**
     * MediaView ID検索
     * @param id    検索するID
     * @return      検索結果
     */
    public List<MediaView> dbSearchMediaViewId(String id) {
        List<MediaView> mediaViewList = new ArrayList<>();
        String sql = "SELECt * " +
                     " FROM MEDIA_VIEW " +
                     " WHERE ID = ? ";
        try {
            ps = con.prepareStatement(sql);     // SQLを実行するためのステートメント作成
            ps.setString(1, id);                // パラメータの1番目にidを設定
            mediaViewList = selectMediaViewExecute(); // SQLの実行
       }
       catch (SQLException e) {    
           e.printStackTrace();    
       }        
       return mediaViewList;
    }
    /**
     * MediaView KIND, CATEGORY検索
     * @param id
     * @return 検索結果
     */
    public List<MediaView> dbSearchMediaViewKindCategory(String kind, String category) {
        List<MediaView> mediaViewList = new ArrayList<>();
        String sql = "SELECt * " +
                     " FROM MEDIA_VIEW " +
                     " WHERE KIND = ? AND CATEGORY = ?" + // パラメータが2つ
                     " ORDER BY ID";
        try {
            ps = con.prepareStatement(sql);     // SQLを実行するためのステートメント作成
            ps.setString(1, kind);              // 1つ目のパラメータに値を設定
            ps.setString(2, category);          // 2つ目のパラメータに値を設定
            mediaViewList = selectMediaViewExecute(); // SQLの実行
       }
       catch (SQLException e) {    
           e.printStackTrace();    
       }        
       return mediaViewList;
    }
    public static void main(String[] args) {
        List<MediaView> mediaViewList   = new ArrayList<>();
        MediaViewDAO    mediaViewDAO    = new MediaViewDAO();
        
        System.out.println("---------------------------------- 全件検索");
        mediaViewList = mediaViewDAO.dbSearchMediaViewAll();    // 全件検索
        System.out.println("件数 = " + mediaViewList.size());
        for (MediaView mediaView : mediaViewList) {
            System.out.println(mediaView);
        }
        System.out.println("---------------------------------- ID検索");
        String[] ids  = {"M00001", "M00002", "M00003", "M00006", "M00007" }; 
        for (String id : ids) {
            mediaViewList = mediaViewDAO.dbSearchMediaViewId(id);    // ID検索
            System.out.print(id + " : ");
            for (MediaView mediaView : mediaViewList) {
                System.out.println(mediaView);
            }
        }
        System.out.println("---------------------------------- KIND and CATEGORY検索");
        String[] kinds  = {"VIDEO", "DVD", "CD" };
        String[] categorys = {"邦画", "洋画", "アニメ"};
        for (String kind : kinds) {
            for (String category : categorys) {
                mediaViewList = mediaViewDAO.dbSearchMediaViewKindCategory(kind, category);    // KIND & CATEGORY検索
                System.out.println(kind + "&" + category + " 件数 = " + mediaViewList.size());
                for (MediaView mediaView : mediaViewList) {
                    System.out.println(mediaView);
                }
            }
        }
    }
}
