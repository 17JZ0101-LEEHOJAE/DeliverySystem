/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  17jz0101 Lee Ho Jae
 * Created: 2018/11/28
 */

INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00001', 2, 'DVD');
INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00002', 2, 'VIDEO');
INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00003', 1, 'VIDEO');
INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00004', 1, 'DVD');
INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00005', 3, 'VIDEO');
INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00006', 4, 'DVD');
INSERT INTO USER01.MEDIA (ID, CATALOG_ID, KIND) VALUES ('M00007', 5, 'VIDEO');

