package dbMediaView;

import java.util.ArrayList;
import java.util.List;

/**Z
 * メディアビュー検索コントロール
 * @author 17jz0101 Lee Ho Jae
 */
class ControlMediaView {
    private BoundaryMediaView   boundary;       // バウンダリ
    private MediaViewDAO        mediaViewDAO;   // MedaiViewDAO
    private List<MediaView>     mediaViewList;  // MediaViewリスト
    
    public ControlMediaView() {
        boundary        = new BoundaryMediaView();  // バウンダリの生成
        mediaViewDAO    = new MediaViewDAO();       // DAOの生成
        mediaViewList   = new ArrayList<>();        // エンティティリストの生成
    }
    public void start() {
        boundary.setControl(this);   // バウンダリにコントローラを設定
        boundary.setVisible(true);      // バウンダリを表示
    }
    /**
     * メディアビューの全件検索
     */
    public void showMediaViewAll() {
        mediaViewList = mediaViewDAO.dbSearchMediaViewAll();
        showMediaViewTable();
    }
    /**
     * エンティティ(MediaView)リストから1件ずつ取出し、
	 *   バウンダリのテーブルモデルへのデータセットと表示を依頼
     */
    public void showMediaViewTable() {
        for (MediaView m : mediaViewList) {
                     // mediaViewList内1件の内容を ", " を区切り文字として分割しrowData配列に格納
            String[] rowData = m.toString().split(", ", 4);
            boundary.addMediaViewTable(rowData);
        }
    }

    /**
     * ID指定による検索
     * @param mediaId 
     */
    public void showMediaViewId(String mediaId) {
        mediaViewList = mediaViewDAO.dbSearchMediaViewId(mediaId); 
        showMediaViewTable();
    }
    
    
    public void showMediaViewkindCategory(String kind, String category) {
        mediaViewList = mediaViewDAO.dbSearchMediaViewKindCategory(kind, category);
        showMediaViewTable();
    }
    
     /**
     * メインメソッド　このメインメソッドから起動する
     * @param args 
     */
    public static void main(String[] args) {
        new ControlMediaView().start();  // コントローラをnewし、start()メソッドを呼び出す
    }   
}
