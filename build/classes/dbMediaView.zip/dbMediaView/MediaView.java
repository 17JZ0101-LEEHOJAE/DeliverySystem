/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbMediaView;

import java.util.ArrayList;
import java.util.List;

/**
 * MediaView
 * @author 17jz0101 Lee Ho Jae
 */
public class MediaView {
    private String      id;
    private String      kind;
    private String      category;
    private String      title;

    public MediaView() {
    }

    public MediaView(String id, String kind, String category, String title) {
        this.id = id;
        this.kind = kind;
        this.category = category;
        this.title = title;
    }
    
    @Override
    public String toString() {
        return id + ", " + kind + ", " + category + ", " + title;
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public String getKind() {
        return kind;
    }

    public String getCategory() {
        return category;
    }

    public String getTitle() {
        return title;
    }
    
    public static void main(String[] args) {
        List<MediaView> mediaViewList = new ArrayList<>();
        
        mediaViewList.add(new MediaView("m101", "dvd", "邦画", "シン・ゴジラ"));
        mediaViewList.add(new MediaView("m102", "video", "邦画", "シン・ゴジラ"));
        mediaViewList.add(new MediaView("m103", "video", "洋画", "美女と野獣"));
        mediaViewList.add(new MediaView("m104", "dvd", "洋画", "美女と野獣"));
        mediaViewList.add(new MediaView("m105", "video", "洋画", "アイアンマン"));
        mediaViewList.add(new MediaView("m106", "dvd", "アニメ", "カーズ"));
        mediaViewList.add(new MediaView("m107", "video", "アニメ", "カーズ２"));
        
        for(MediaView mediaView : mediaViewList) {
            System.out.println(mediaView);
        }
    }
}
