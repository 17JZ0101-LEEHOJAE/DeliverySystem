/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  17jz0101 Lee Ho Jae
 * Created: 2018/11/28
 */

INSERT INTO USER01.MEDIA_CATALOG (CATALOG_ID, CATEGORY, TITLE) VALUES (1, '洋画', '美人と野獣');
INSERT INTO USER01.MEDIA_CATALOG (CATALOG_ID, CATEGORY, TITLE) VALUES (2, '邦画', 'シン・ゴジラ');
INSERT INTO USER01.MEDIA_CATALOG (CATALOG_ID, CATEGORY, TITLE) VALUES (3, '洋画', 'アイアンマン');
INSERT INTO USER01.MEDIA_CATALOG (CATALOG_ID, CATEGORY, TITLE) VALUES (4, 'アニメ', 'カーズ');
INSERT INTO USER01.MEDIA_CATALOG (CATALOG_ID, CATEGORY, TITLE) VALUES (5, 'アニメ', 'カーズ２');
